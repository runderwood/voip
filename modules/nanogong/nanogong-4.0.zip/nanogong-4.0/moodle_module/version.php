<?php // $Id: version.php,v 4 2010/04/22 00:00:00 gibson Exp $

$module->version  = 2010042200;  // The current module version (Date: YYYYMMDDXX)
$module->cron     = 0;           // Period for cron to check this module (secs)

?>
