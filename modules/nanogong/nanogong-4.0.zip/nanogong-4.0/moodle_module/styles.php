.nanogong_title {
    font-weight: bold;
}
.nanogong_messagelist,
.nanogong_messagelist input,
.nanogong_submitdate {
    font-size: 80%;
}
